﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CongestionTaxCalculator.Domain.CongestionTaxRules;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CongestionTaxCalculator.Infrastructure.Configurations;


public class RuleConfiguration : IEntityTypeConfiguration<CongestionTaxRule>
{
    public void Configure(EntityTypeBuilder<CongestionTaxRule> builder)
    {
        builder.ToTable("Rules");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
               .ValueGeneratedOnAdd();

        builder.Property(x => x.DailyCap)
               .HasColumnType("decimal(18,2)")
               .IsRequired();

        builder.Property(x => x.SingleChargePeriodMinutes)
               .IsRequired();

        builder.HasMany(x => x.TaxPeriods)
               .WithOne()
               .HasForeignKey(x => x.RuleId);

        builder.HasMany(x => x.TollExemptVehicles)
               .WithOne()
               .HasForeignKey(x => x.RuleId);
    }
}

