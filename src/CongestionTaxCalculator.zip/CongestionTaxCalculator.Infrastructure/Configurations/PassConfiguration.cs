﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CongestionTaxCalculator.Infrastructure.Configurations;


public class PassConfiguration : IEntityTypeConfiguration<Pass>
{
    public void Configure(EntityTypeBuilder<Pass> builder)
    {
        builder.ToTable("Passes");

        // Composite Key
        builder.HasKey(x => new { x.VehicleId, x.PassMoment });

        builder.Property(x => x.PassMoment)
               .HasColumnType("datetime2(0)")
               .IsRequired();

        builder.HasOne(x => x.Vehicle)
               .WithMany(x => x.Passes)
               .HasForeignKey(x => x.VehicleId);
    }
}

