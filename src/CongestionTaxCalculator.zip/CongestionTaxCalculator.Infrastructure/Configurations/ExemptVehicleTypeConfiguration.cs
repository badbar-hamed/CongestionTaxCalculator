﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CongestionTaxCalculator.Infrastructure.Configurations;


public class ExemptVehicleTypeConfiguration : IEntityTypeConfiguration<ExemptVehicleType>
{
    public void Configure(EntityTypeBuilder<ExemptVehicleType> builder)
    {
        builder.ToTable("ExemptVehicleTypes");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
               .ValueGeneratedOnAdd();

        builder.Property(x => x.RuleId)
               .IsRequired();

        builder.Property(x => x.VehicleTypeId)
               .IsRequired();
    }
}

