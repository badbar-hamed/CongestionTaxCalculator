﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CongestionTaxCalculator.Domain.CongestionTaxRules;
using Microsoft.EntityFrameworkCore;


namespace CongestionTaxCalculator.Infrastructure;

public class CongestionTaxDbContext : DbContext
{
    public CongestionTaxDbContext(DbContextOptions<CongestionTaxDbContext> options)
        : base(options)
    {
    }

    // --- DbSets (Tables) ---
    public DbSet<VehicleType> VehicleTypes { get; set; }
    public DbSet<Vehicle> Vehicles { get; set; }
    public DbSet<Pass> Passes { get; set; }

    public DbSet<CongestionTaxRule> Rules { get; set; }
    public DbSet<TaxPeriod> RulePeriods { get; set; }
    public DbSet<ExemptVehicleType> ExemptVehicleTypes { get; set; }

    public DbSet<HolidayCalendar> HolidayCalendar { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // --- Apply All Configuration Classes Automatically ---
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(CongestionTaxDbContext).Assembly);

        base.OnModelCreating(modelBuilder);
    }
}


