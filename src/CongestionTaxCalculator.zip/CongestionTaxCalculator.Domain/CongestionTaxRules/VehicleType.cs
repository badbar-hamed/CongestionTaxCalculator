﻿using CongestionTaxCalculator.Domain.Core;

namespace CongestionTaxCalculator.Domain.CongestionTaxRules
{
    public class VehicleType:Entity<int>
    {
        public int Id { get; private set; }
        public string Title { get; private set; }

        private VehicleType() { } 

        public VehicleType(string title)
        {
            Title = title;
        }
    }
}
